fx_version 'cerulean'

game 'gta5'

author 'mt scripts'

description 'OsTeam-AmmRobbery'

version '0.2'

shared_scripts {
    '@qb-core/shared/locale.lua',
    'locales/en.lua',
    'config/config.lua',
}

client_scripts{
    'client/osTeam_cl.lua',
    'client/steal.lua',
}

server_scripts{
    'server/OsTeam_sv.lua',
}
