local QBCore = exports['qb-core']:GetCoreObject()
local Cooldown = {}

RegisterServerEvent('OsTeam-AmmRobbery:server:getVitrineItems', function(Osli_Key) 
    local src = source
    local Player  = QBCore.Functions.GetPlayer(src)
    local prob = math.random(1, 100)
    local vitrine = Config.OsTeamAmmunation[Osli_Key]
    local itemFound = false
    for i = 1, #vitrine.items do
        if(prob <= vitrine.items[i].maxChance and prob >= vitrine.items[i].minChance) then
            itemFound = true
            local quantity = math.random(vitrine.items[i].minQuantity, vitrine.items[i].maxQuantity)
            if Player.Functions.AddItem(vitrine.items[i].item, quantity) then
                TriggerClientEvent('inventory:client:ItemBox', src, QBCore.Shared.Items[vitrine.items[i].item], 'add')
            else
                TriggerClientEvent('QBCore:Notify', src, Lang:t("ammurobbery.error_inventory"), 'error')
            end  
        end
    end

    if not itemFound then
        TriggerClientEvent('QBCore:Notify', src, 'This is empty...', 'error')
    end
end)

-- Cooldown
RegisterServerEvent('OsTeam-AmmRobbery:Server:CooldownVitrines')
AddEventHandler('OsTeam-AmmRobbery:Server:CooldownVitrines', function(Osli_Key)
    if not Cooldown[Osli_Key] then
        Cooldown[Osli_Key] = true
        CreateThread(function()
            Wait(Config.cooldownTimer)
            Cooldown[Osli_Key] = false
        end)
    end
end)

QBCore.Functions.CreateCallback("OsTeam-AmmRobbery:CooldownVitrines",function(source, cb, Osli_Key)
    cb(Cooldown[Osli_Key])
end)
